Solardach Energie Dashboard
Author: Oihika Arpit

Project Type:
Solar rooftop PV + Battery Energy Storage simulation dashboard for German cities.

Selected Parameters:
City: Freiburg
Year: 2024
PV system size: 7.0 kWp
Battery size: 8.0 kWh
Annual household load: 4200 kWh
Tariff scenario: BDEW average household

Main Results:
Annual demand: 4,200 kWh
Annual PV generation: 6,839 kWh
Annual self-consumed energy: 3,409 kWh
Annual grid import: 791 kWh
Annual grid export: 3,232 kWh
Self-consumption rate: 49.9%
Self-sufficiency rate: 81.2%
Annual savings: EUR 1,513
System cost: EUR 16,100
Payback period: 10.64 years
CO2 avoided annually: 1.30 tonnes

Output Files:
1. hourly_pv_bess_simulation.csv
2. monthly_energy_summary.csv
3. german_tariff_comparison.csv
4. colorful_solardach_dashboard.html
5. colorful_monthly_energy_balance.png
6. colorful_grid_import_export.png
7. colorful_hourly_pv_battery_grid.png
8. colorful_tariff_savings_comparison.png
9. colorful_payback_comparison.png
10. colorful_monthly_co2_avoided.png
11. colorful_daily_pv_generation_trend.png
12. colorful_annual_energy_flow_pie.png

How to Explain This Project:
This project compares rooftop solar generation, household demand, battery storage, grid import, grid export, tariff savings, payback period, and CO2 reduction for German cities. It is useful for MSc Renewable Energy, smart grid, solar PV, energy management, and battery storage profile building.